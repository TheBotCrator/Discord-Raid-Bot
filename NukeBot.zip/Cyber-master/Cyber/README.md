# Cyber | Made by appellation and ItsJordan.
> Please note that adding this bot will destroy your server!

This is a bot that appellation and I have made as a joke. 
It's built in [Discord.js](https://discord.js.org/#/) version 11.0 and makes use of ES7 features. 

## Downloading

Make sure git is installed on your machine and run the following command:

`git clone https://github.com/ItsJordan/Cyber.git`

Once finished: 
- `cd Cyber`
- `npm install`
- Rename `config.json.example` to `config.json`
- Edit `config.json` and enter your token

## Getting your login token

> Remember, we are not responsible for any damage caused and cannot be held liable if you are punished.

1. Go to https://discordapp.com/developers/applications/me.
2. This brings up your **Apps**. Go to the your application's tab
3. Locate the entry called `token`, and copy it.
4. Enter the token into your `config.json`.

**Remember to never share your token with anyone!**

## Starting the bot

To start the bot, in the command prompt, run the following command:
`npm start`
